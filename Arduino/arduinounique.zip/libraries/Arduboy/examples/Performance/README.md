### Benchmark run as of June 2015

- drawPixel
- drawTriangle
- fillTriangle
- drawRect
- fillRect
- drawCircle
- fillCircle
- drawRoundRect
- fillRoundRect
- drawLine
- drawFastHLine
- drawFastVLine
- drawBitmap
- drawSlowBitmap
- paint
